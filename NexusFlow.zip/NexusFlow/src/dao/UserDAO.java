package dao;

import model.Role;
import model.User;
import util.DBConnection;

import java.sql.*;

public class UserDAO {

    public User findByUsername(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ?";
        Connection conn = DBConnection.getConnection();
        
        if (conn == null) {
            System.err.println("❌ Could not connect to MySQL. Make sure MySQL Server is running and password in DBConnection.java is correct.");
            return null;
        }

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new User(
                            rs.getInt("id"),
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("full_name"),
                            rs.getString("email"),
                            Role.fromString(rs.getString("role")),
                            rs.getTimestamp("created_at")
                    );
                }
            }
        } finally {
            if (conn != null) conn.close();
        }
        return null;
    }
}