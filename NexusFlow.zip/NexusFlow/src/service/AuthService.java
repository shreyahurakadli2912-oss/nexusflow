package service;

import dao.UserDAO;
import model.User;

import java.sql.SQLException;

public class AuthService {

    private final UserDAO userDAO = new UserDAO();
    private User currentUser;

    public User login(String username, String password) throws SQLException {
        User user = userDAO.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            this.currentUser = user;
            return user;
        }
        return null;
    }

    public User getCurrentUser() {
        return currentUser;
    }
}