package ui;

import model.*;
import service.AuthService;
import service.LeaveService;
import service.AdminService;
import dao.AuditLogDAO;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class ConsoleUI {

    private final Scanner scanner = new Scanner(System.in);
    private final AuthService authService = new AuthService();
    private final LeaveService leaveService = new LeaveService();
    private final AdminService adminService = new AdminService();
    private final AuditLogDAO auditLogDAO = new AuditLogDAO();

    public void start() {
        System.out.println("==================================================");
        System.out.println("  WELCOME TO NEXUSFLOW WORKFLOW AUTOMATION PLATFORM");
        System.out.println("==================================================");

        boolean running = true;
        while (running) {
            System.out.println("\n--- MAIN MENU ---");
            System.out.println("1. Login");
            System.out.println("2. Exit System");
            System.out.print("Select an option (1-2): ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    handleLogin();
                    break;
                case "2":
                    System.out.println("\nThank you for using NexusFlow. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("❌ Invalid choice. Please enter 1 or 2.");
            }
        }
    }

    private void handleLogin() {
        System.out.print("\nEnter Username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine().trim();

        try {
            User user = authService.login(username, password);
            if (user != null) {
                System.out.println("\n✅ Login Successful! Welcome, " + user.getFullName() + " (" + user.getRole() + ")");
                routeRoleDashboard(user);
            } else {
                System.out.println("❌ Invalid username or password.");
            }
        } catch (SQLException e) {
            System.err.println("❌ Database Error: " + e.getMessage());
        }
    }

    private void routeRoleDashboard(User user) {
        if (user.getRole() == null) return;
        switch (user.getRole()) {
            case EMPLOYEE:
                showEmployeeDashboard(user);
                break;
            case MANAGER:
                showManagerDashboard(user);
                break;
            case HR:
                showHrDashboard(user);
                break;
            case ADMIN:
                showAdminDashboard(user);
                break;
        }
    }

    private void showEmployeeDashboard(User user) {
        boolean active = true;
        while (active) {
            System.out.println("\n--- EMPLOYEE DASHBOARD (" + user.getFullName() + ") ---");
            System.out.println("1. Apply for Leave");
            System.out.println("2. View My Leave History");
            System.out.println("3. Logout");
            System.out.print("Select option: ");

            String choice = scanner.nextLine().trim();
            try {
                if (choice.equals("1")) {
                    System.out.print("Leave Type (SICK, CASUAL, ANNUAL): ");
                    String type = scanner.nextLine().trim();
                    System.out.print("Start Date (YYYY-MM-DD): ");
                    Date start = Date.valueOf(scanner.nextLine().trim());
                    System.out.print("End Date (YYYY-MM-DD): ");
                    Date end = Date.valueOf(scanner.nextLine().trim());
                    System.out.print("Reason: ");
                    String reason = scanner.nextLine().trim();

                    if (leaveService.applyForLeave(user, type, start, end, reason)) {
                        System.out.println("✅ Leave Request submitted! Initial Status: PENDING_MANAGER");
                    }
                } else if (choice.equals("2")) {
                    displayTable(leaveService.getEmployeeLeaveRequests(user.getId()));
                } else if (choice.equals("3")) {
                    active = false;
                }
            } catch (Exception e) {
                System.out.println("❌ Error: " + e.getMessage());
            }
        }
    }

    private void showManagerDashboard(User user) {
        boolean active = true;
        while (active) {
            System.out.println("\n--- MANAGER DASHBOARD (" + user.getFullName() + ") ---");
            System.out.println("1. View Pending Manager Approvals");
            System.out.println("2. Approve / Reject Request");
            System.out.println("3. Logout");
            System.out.print("Select option: ");

            String choice = scanner.nextLine().trim();
            try {
                if (choice.equals("1")) {
                    displayTable(leaveService.getManagerPendingRequests());
                } else if (choice.equals("2")) {
                    System.out.print("Enter Leave Request ID: ");
                    int id = Integer.parseInt(scanner.nextLine().trim());
                    System.out.print("Decision (1 = Approve, 2 = Reject): ");
                    boolean approve = scanner.nextLine().trim().equals("1");
                    System.out.print("Enter Comment: ");
                    String comment = scanner.nextLine().trim();

                    if (leaveService.processManagerDecision(user, id, approve, comment)) {
                        System.out.println("✅ Request updated! Status: " + (approve ? "PENDING_HR" : "REJECTED_BY_MANAGER"));
                    }
                } else if (choice.equals("3")) {
                    active = false;
                }
            } catch (Exception e) {
                System.out.println("❌ Error: " + e.getMessage());
            }
        }
    }

    private void showHrDashboard(User user) {
        boolean active = true;
        while (active) {
            System.out.println("\n--- HR DASHBOARD (" + user.getFullName() + ") ---");
            System.out.println("1. View Pending HR Approvals");
            System.out.println("2. Process Final Approval / Rejection");
            System.out.println("3. Logout");
            System.out.print("Select option: ");

            String choice = scanner.nextLine().trim();
            try {
                if (choice.equals("1")) {
                    displayTable(leaveService.getHrPendingRequests());
                } else if (choice.equals("2")) {
                    System.out.print("Enter Leave Request ID: ");
                    int id = Integer.parseInt(scanner.nextLine().trim());
                    System.out.print("Decision (1 = Final Approve, 2 = Reject): ");
                    boolean approve = scanner.nextLine().trim().equals("1");
                    System.out.print("Enter HR Comment: ");
                    String comment = scanner.nextLine().trim();

                    if (leaveService.processHrDecision(user, id, approve, comment)) {
                        System.out.println("✅ HR Decision Saved! Final Status: " + (approve ? "APPROVED" : "REJECTED_BY_HR"));
                    }
                } else if (choice.equals("3")) {
                    active = false;
                }
            } catch (Exception e) {
                System.out.println("❌ Error: " + e.getMessage());
            }
        }
    }

    private void showAdminDashboard(User user) {
        boolean active = true;
        while (active) {
            System.out.println("\n--- ADMINISTRATOR DASHBOARD (" + user.getFullName() + ") ---");
            System.out.println("1. View All Leave Requests");
            System.out.println("2. View Audit Logs");
            System.out.println("3. Export Audit Logs to CSV File");
            System.out.println("4. Logout");
            System.out.print("Select option: ");

            String choice = scanner.nextLine().trim();
            try {
                if (choice.equals("1")) {
                    displayTable(leaveService.getAllLeaveRequests());
                } else if (choice.equals("2")) {
                    List<AuditLog> logs = auditLogDAO.findAll();
                    for (AuditLog log : logs) {
                        System.out.printf("[%s] User #%d (%s) -> Action: %s | %s\n",
                                log.getTimestamp(), log.getUserId(), log.getUserRole(), log.getAction(), log.getDetails());
                    }
                } else if (choice.equals("3")) {
                    String fileName = "nexusflow_audit_logs.csv";
                    if (adminService.exportAuditLogsToCSV(fileName)) {
                        System.out.println("✅ Audit Logs successfully exported to file: " + fileName);
                    }
                } else if (choice.equals("4")) {
                    active = false;
                }
            } catch (Exception e) {
                System.out.println("❌ Error: " + e.getMessage());
            }
        }
    }

    private void displayTable(List<LeaveRequest> list) {
        if (list == null || list.isEmpty()) {
            System.out.println("ℹ️ No records found.");
            return;
        }
        System.out.printf("%-4s | %-18s | %-8s | %-10s | %-10s | %-20s\n", "ID", "Employee", "Type", "Start", "End", "Status");
        System.out.println("-----------------------------------------------------------------------------");
        for (LeaveRequest r : list) {
            System.out.printf("%-4d | %-18s | %-8s | %-10s | %-10s | %-20s\n",
                    r.getId(), r.getEmployeeName(), r.getLeaveType(), r.getStartDate(), r.getEndDate(), r.getStatus());
        }
    }
}