# NexusFlow – Universal Enterprise Workflow Automation Platform

NexusFlow is a Full-Stack Enterprise Workflow Engine built in **Java**, **JDBC**, **MySQL**, and **HTML5/CSS3/JavaScript**.

---

## ⚡ How to Run and View the Web Dashboards

### Step 1: Extract the ZIP
Unzip `NexusFlow.zip` on your computer.

### Step 2: Open Terminal / Command Prompt
Open Command Prompt inside the `NexusFlow` project directory and run these 2 commands:

```cmd
javac -d bin -cp "lib/*" src/main/Main.java src/model/*.java src/util/*.java src/dao/*.java src/service/*.java src/server/*.java src/ui/*.java
```

```cmd
java -cp "bin;lib/*" main.Main
```

You will see:
```text
==================================================
🚀 NexusFlow Universal Web Server running on port 8080
🌐 Open http://localhost:8080 in your browser!
==================================================
```

### Step 3: Open in Web Browser
Open your browser (Chrome/Edge/Firefox) and go to:
👉 **`http://localhost:8080`**

---

## 🔑 Demo Test Accounts & Passwords

| Role | Username | Unique Password | Actions Available |
| :--- | :--- | :--- | :--- |
| 🧑‍💻 **Employee** | `emp_john` | `Emp@John2026` | Apply for Leave, Submit Expenses, Raise Purchase Requests |
| 👨‍💼 **Manager** | `mgr_bob` | `Mgr@Bob2026` | Review Level-1 Queues across Leave, Expenses, Purchases |
| 👩‍💼 **HR / Finance** | `hr_sarah` | `Hr@Sarah2026` | Final Level-2 Sign-off, Expense Reimbursements, PO Orders |
| 🛠️ **Admin** | `admin` | `Admin@Nexus2026` | System Audit Trail timeline, Export Audit Logs CSV |
