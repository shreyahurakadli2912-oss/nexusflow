package dao;

import model.AuditLog;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AuditLogDAO {

    public boolean logAction(AuditLog log) {
        String sql = "INSERT INTO audit_logs (user_id, user_role, action, details) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, log.getUserId());
            stmt.setString(2, log.getUserRole());
            stmt.setString(3, log.getAction());
            stmt.setString(4, log.getDetails());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("❌ Audit log failed: " + e.getMessage());
            return false;
        }
    }

    public List<AuditLog> findAll() throws SQLException {
        List<AuditLog> list = new ArrayList<>();
        String sql = "SELECT * FROM audit_logs ORDER BY timestamp DESC";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                AuditLog log = new AuditLog();
                log.setId(rs.getInt("id"));
                log.setUserId(rs.getInt("user_id"));
                log.setUserRole(rs.getString("user_role"));
                log.setAction(rs.getString("action"));
                log.setDetails(rs.getString("details"));
                log.setTimestamp(rs.getTimestamp("timestamp"));
                list.add(log);
            }
        }
        return list;
    }
}