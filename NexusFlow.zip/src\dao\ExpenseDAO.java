package dao;

import model.ExpenseClaim;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ExpenseDAO {

    public boolean createClaim(ExpenseClaim claim) throws SQLException {
        String sql = "INSERT INTO expense_claims (employee_id, category, amount, description, status) VALUES (?, ?, ?, ?, 'PENDING_MANAGER')";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, claim.getEmployeeId());
            stmt.setString(2, claim.getCategory());
            stmt.setDouble(3, claim.getAmount());
            stmt.setString(4, claim.getDescription());
            return stmt.executeUpdate() > 0;
        }
    }

    public List<ExpenseClaim> findByEmployeeId(int empId) throws SQLException {
        String sql = "SELECT e.*, u.full_name as employee_name FROM expense_claims e JOIN users u ON e.employee_id = u.id WHERE e.employee_id = ? ORDER BY e.created_at DESC";
        return fetchList(sql, stmt -> stmt.setInt(1, empId));
    }

    public List<ExpenseClaim> findByStatus(String status) throws SQLException {
        String sql = "SELECT e.*, u.full_name as employee_name FROM expense_claims e JOIN users u ON e.employee_id = u.id WHERE e.status = ? ORDER BY e.created_at ASC";
        return fetchList(sql, stmt -> stmt.setString(1, status));
    }

    public List<ExpenseClaim> findAll() throws SQLException {
        String sql = "SELECT e.*, u.full_name as employee_name FROM expense_claims e JOIN users u ON e.employee_id = u.id ORDER BY e.created_at DESC";
        return fetchList(sql, null);
    }

    public boolean updateStatusAndManagerComment(int id, String status, String comment) throws SQLException {
        String sql = "UPDATE expense_claims SET status = ?, manager_comment = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setString(2, comment);
            stmt.setInt(3, id);
            return stmt.executeUpdate() > 0;
        }
    }

    public boolean updateStatusAndFinanceComment(int id, String status, String comment) throws SQLException {
        String sql = "UPDATE expense_claims SET status = ?, finance_comment = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setString(2, comment);
            stmt.setInt(3, id);
            return stmt.executeUpdate() > 0;
        }
    }

    @FunctionalInterface
    private interface Setter { void set(PreparedStatement stmt) throws SQLException; }

    private List<ExpenseClaim> fetchList(String sql, Setter setter) throws SQLException {
        List<ExpenseClaim> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (setter != null) setter.set(stmt);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    ExpenseClaim c = new ExpenseClaim();
                    c.setId(rs.getInt("id"));
                    c.setEmployeeId(rs.getInt("employee_id"));
                    c.setEmployeeName(rs.getString("employee_name"));
                    c.setCategory(rs.getString("category"));
                    c.setAmount(rs.getDouble("amount"));
                    c.setDescription(rs.getString("description"));
                    c.setStatus(rs.getString("status"));
                    c.setManagerComment(rs.getString("manager_comment"));
                    c.setFinanceComment(rs.getString("finance_comment"));
                    c.setCreatedAt(rs.getTimestamp("created_at"));
                    list.add(c);
                }
            }
        }
        return list;
    }
}
