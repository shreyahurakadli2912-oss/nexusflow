package dao;

import model.LeaveRequest;
import model.LeaveStatus;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LeaveRequestDAO {

    public boolean createLeaveRequest(LeaveRequest request) throws SQLException {
        String sql = "INSERT INTO leave_requests (employee_id, leave_type, start_date, end_date, reason, status) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, request.getEmployeeId());
            stmt.setString(2, request.getLeaveType());
            stmt.setDate(3, request.getStartDate());
            stmt.setDate(4, request.getEndDate());
            stmt.setString(5, request.getReason());
            stmt.setString(6, LeaveStatus.PENDING_MANAGER.name());
            return stmt.executeUpdate() > 0;
        }
    }

    public List<LeaveRequest> findByEmployeeId(int employeeId) throws SQLException {
        String sql = "SELECT l.*, COALESCE(u.full_name, 'Employee') as employee_name FROM leave_requests l " +
                     "LEFT JOIN users u ON l.employee_id = u.id " +
                     "WHERE l.employee_id = ? ORDER BY l.created_at DESC";
        return fetchList(sql, stmt -> stmt.setInt(1, employeeId));
    }

    public List<LeaveRequest> findByStatus(LeaveStatus status) throws SQLException {
        String sql = "SELECT l.*, COALESCE(u.full_name, 'Employee') as employee_name FROM leave_requests l " +
                     "LEFT JOIN users u ON l.employee_id = u.id " +
                     "WHERE l.status = ? ORDER BY l.created_at ASC";
        return fetchList(sql, stmt -> stmt.setString(1, status.name()));
    }

    public List<LeaveRequest> findAll() throws SQLException {
        String sql = "SELECT l.*, COALESCE(u.full_name, 'Employee') as employee_name FROM leave_requests l " +
                     "LEFT JOIN users u ON l.employee_id = u.id ORDER BY l.created_at DESC";
        return fetchList(sql, null);
    }

    public LeaveRequest findById(int id) throws SQLException {
        String sql = "SELECT l.*, COALESCE(u.full_name, 'Employee') as employee_name FROM leave_requests l " +
                     "LEFT JOIN users u ON l.employee_id = u.id WHERE l.id = ?";
        List<LeaveRequest> list = fetchList(sql, stmt -> stmt.setInt(1, id));
        return list.isEmpty() ? null : list.get(0);
    }

    public boolean updateStatusAndManagerComment(int id, LeaveStatus newStatus, String comment) throws SQLException {
        String sql = "UPDATE leave_requests SET status = ?, manager_comment = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, newStatus.name());
            stmt.setString(2, comment);
            stmt.setInt(3, id);
            return stmt.executeUpdate() > 0;
        }
    }

    public boolean updateStatusAndHrComment(int id, LeaveStatus newStatus, String comment) throws SQLException {
        String sql = "UPDATE leave_requests SET status = ?, hr_comment = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, newStatus.name());
            stmt.setString(2, comment);
            stmt.setInt(3, id);
            return stmt.executeUpdate() > 0;
        }
    }

    @FunctionalInterface
    private interface Setter { void set(PreparedStatement stmt) throws SQLException; }

    private List<LeaveRequest> fetchList(String sql, Setter setter) throws SQLException {
        List<LeaveRequest> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (setter != null) setter.set(stmt);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    LeaveRequest req = new LeaveRequest();
                    req.setId(rs.getInt("id"));
                    req.setEmployeeId(rs.getInt("employee_id"));
                    req.setEmployeeName(rs.getString("employee_name"));
                    req.setLeaveType(rs.getString("leave_type"));
                    req.setStartDate(rs.getDate("start_date"));
                    req.setEndDate(rs.getDate("end_date"));
                    req.setReason(rs.getString("reason"));
                    req.setStatus(LeaveStatus.fromString(rs.getString("status")));
                    req.setManagerComment(rs.getString("manager_comment"));
                    req.setHrComment(rs.getString("hr_comment"));
                    req.setCreatedAt(rs.getTimestamp("created_at"));
                    req.setUpdatedAt(rs.getTimestamp("updated_at"));
                    list.add(req);
                }
            }
        }
        return list;
    }
}