package dao;

import model.PurchaseRequest;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PurchaseDAO {

    public boolean createRequest(PurchaseRequest req) throws SQLException {
        String sql = "INSERT INTO purchase_requests (employee_id, item_name, quantity, estimated_cost, reason, status) VALUES (?, ?, ?, ?, ?, 'PENDING_MANAGER')";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, req.getEmployeeId());
            stmt.setString(2, req.getItemName());
            stmt.setInt(3, req.getQuantity());
            stmt.setDouble(4, req.getEstimatedCost());
            stmt.setString(5, req.getReason());
            return stmt.executeUpdate() > 0;
        }
    }

    public List<PurchaseRequest> findByEmployeeId(int empId) throws SQLException {
        String sql = "SELECT p.*, COALESCE(u.full_name, 'Employee') as employee_name FROM purchase_requests p LEFT JOIN users u ON p.employee_id = u.id WHERE p.employee_id = ? ORDER BY p.created_at DESC";
        return fetchList(sql, stmt -> stmt.setInt(1, empId));
    }

    public List<PurchaseRequest> findByStatus(String status) throws SQLException {
        String sql = "SELECT p.*, COALESCE(u.full_name, 'Employee') as employee_name FROM purchase_requests p LEFT JOIN users u ON p.employee_id = u.id WHERE p.status = ? ORDER BY p.created_at ASC";
        return fetchList(sql, stmt -> stmt.setString(1, status));
    }

    public List<PurchaseRequest> findAll() throws SQLException {
        String sql = "SELECT p.*, COALESCE(u.full_name, 'Employee') as employee_name FROM purchase_requests p LEFT JOIN users u ON p.employee_id = u.id ORDER BY p.created_at DESC";
        return fetchList(sql, null);
    }

    public boolean updateStatusAndManagerComment(int id, String status, String comment) throws SQLException {
        String sql = "UPDATE purchase_requests SET status = ?, manager_comment = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setString(2, comment);
            stmt.setInt(3, id);
            return stmt.executeUpdate() > 0;
        }
    }

    public boolean updateStatusAndFinanceComment(int id, String status, String comment) throws SQLException {
        String sql = "UPDATE purchase_requests SET status = ?, finance_comment = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setString(2, comment);
            stmt.setInt(3, id);
            return stmt.executeUpdate() > 0;
        }
    }

    @FunctionalInterface
    private interface Setter { void set(PreparedStatement stmt) throws SQLException; }

    private List<PurchaseRequest> fetchList(String sql, Setter setter) throws SQLException {
        List<PurchaseRequest> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (setter != null) setter.set(stmt);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    PurchaseRequest p = new PurchaseRequest();
                    p.setId(rs.getInt("id"));
                    p.setEmployeeId(rs.getInt("employee_id"));
                    p.setEmployeeName(rs.getString("employee_name"));
                    p.setItemName(rs.getString("item_name"));
                    p.setQuantity(rs.getInt("quantity"));
                    p.setEstimatedCost(rs.getDouble("estimated_cost"));
                    p.setReason(rs.getString("reason"));
                    p.setStatus(rs.getString("status"));
                    p.setManagerComment(rs.getString("manager_comment"));
                    p.setFinanceComment(rs.getString("finance_comment"));
                    p.setCreatedAt(rs.getTimestamp("created_at"));
                    list.add(p);
                }
            }
        }
        return list;
    }
}
