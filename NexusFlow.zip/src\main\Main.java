package main;

import server.WebServer;

public class Main {

    public static void main(String[] args) {
        try {
            WebServer.main(args);
        } catch (Exception e) {
            System.err.println("❌ Web Server Launch Error: " + e.getMessage());
        }
    }
}