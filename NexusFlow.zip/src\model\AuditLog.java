package model;

import java.sql.Timestamp;

public class AuditLog {
    private int id;
    private int userId;
    private String userRole;
    private String action;
    private String details;
    private Timestamp timestamp;

    public AuditLog() {}

    public AuditLog(int userId, String userRole, String action, String details) {
        this.userId = userId;
        this.userRole = userRole;
        this.action = action;
        this.details = details;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getUserRole() { return userRole; }
    public void setUserRole(String userRole) { this.userRole = userRole; }
    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }
    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }
    public Timestamp getTimestamp() { return timestamp; }
    public void setTimestamp(Timestamp timestamp) { this.timestamp = timestamp; }
}