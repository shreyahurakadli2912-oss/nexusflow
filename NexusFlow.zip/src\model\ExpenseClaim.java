package model;

import java.sql.Timestamp;

public class ExpenseClaim {
    private int id;
    private int employeeId;
    private String employeeName;
    private String category;
    private double amount;
    private String description;
    private String status; // PENDING_MANAGER, PENDING_FINANCE, REIMBURSED, REJECTED
    private String managerComment;
    private String financeComment;
    private Timestamp createdAt;

    public ExpenseClaim() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getEmployeeId() { return employeeId; }
    public void setEmployeeId(int employeeId) { this.employeeId = employeeId; }

    public String getEmployeeName() { return employeeName; }
    public void setEmployeeName(String employeeName) { this.employeeName = employeeName; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getManagerComment() { return managerComment; }
    public void setManagerComment(String managerComment) { this.managerComment = managerComment; }

    public String getFinanceComment() { return financeComment; }
    public void setFinanceComment(String financeComment) { this.financeComment = financeComment; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
