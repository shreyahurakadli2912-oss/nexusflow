package model;

/**
 * Defines workflow states for leave requests.
 */
public enum LeaveStatus {
    PENDING_MANAGER,
    REJECTED_BY_MANAGER,
    PENDING_HR,
    REJECTED_BY_HR,
    APPROVED,
    CANCELLED;

    public static LeaveStatus fromString(String statusStr) {
        for (LeaveStatus status : LeaveStatus.values()) {
            if (status.name().equalsIgnoreCase(statusStr)) {
                return status;
            }
        }
        return PENDING_MANAGER;
    }
}