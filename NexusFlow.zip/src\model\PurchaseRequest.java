package model;

import java.sql.Timestamp;

public class PurchaseRequest {
    private int id;
    private int employeeId;
    private String employeeName;
    private String itemName;
    private int quantity;
    private double estimatedCost;
    private String reason;
    private String status; // PENDING_MANAGER, PENDING_FINANCE, PENDING_PURCHASE, COMPLETED, REJECTED
    private String managerComment;
    private String financeComment;
    private Timestamp createdAt;

    public PurchaseRequest() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getEmployeeId() { return employeeId; }
    public void setEmployeeId(int employeeId) { this.employeeId = employeeId; }

    public String getEmployeeName() { return employeeName; }
    public void setEmployeeName(String employeeName) { this.employeeName = employeeName; }

    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getEstimatedCost() { return estimatedCost; }
    public void setEstimatedCost(double estimatedCost) { this.estimatedCost = estimatedCost; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getManagerComment() { return managerComment; }
    public void setManagerComment(String managerComment) { this.managerComment = managerComment; }

    public String getFinanceComment() { return financeComment; }
    public void setFinanceComment(String financeComment) { this.financeComment = financeComment; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
