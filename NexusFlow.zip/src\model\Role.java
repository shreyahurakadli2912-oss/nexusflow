package model;

/**
 * Defines the 4 user roles in NexusFlow.
 */
public enum Role {
    ADMIN,
    HR,
    MANAGER,
    EMPLOYEE;

    public static Role fromString(String roleStr) {
        for (Role role : Role.values()) {
            if (role.name().equalsIgnoreCase(roleStr)) {
                return role;
            }
        }
        return EMPLOYEE;
    }
}