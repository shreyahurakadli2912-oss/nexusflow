package server;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import dao.AuditLogDAO;
import model.*;
import service.*;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.util.List;

public class WebServer {

    private static final int PORT = 8080;
    private static final AuthService authService = new AuthService();
    private static final LeaveService leaveService = new LeaveService();
    private static final ExpenseService expenseService = new ExpenseService();
    private static final PurchaseService purchaseService = new PurchaseService();
    private static final AuditLogDAO auditLogDAO = new AuditLogDAO();

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);

        // API Endpoints - Auth & Core
        server.createContext("/api/login", new LoginHandler());
        server.createContext("/api/register", new RegisterHandler());
        server.createContext("/api/audit-logs", new AuditLogsHandler());

        // Leave Endpoints
        server.createContext("/api/leave/apply", new ApplyLeaveHandler());
        server.createContext("/api/leave/employee", new EmployeeLeaveHandler());
        server.createContext("/api/leave/pending-manager", new ManagerPendingHandler());
        server.createContext("/api/leave/process-manager", new ManagerProcessHandler());
        server.createContext("/api/leave/pending-hr", new HrPendingHandler());
        server.createContext("/api/leave/process-hr", new HrProcessHandler());
        server.createContext("/api/leave/all", new AllLeaveHandler());

        // Expense Claims Endpoints
        server.createContext("/api/expense/apply", new ApplyExpenseHandler());
        server.createContext("/api/expense/employee", new EmployeeExpenseHandler());
        server.createContext("/api/expense/pending-manager", new ExpenseManagerPendingHandler());
        server.createContext("/api/expense/process-manager", new ExpenseManagerProcessHandler());
        server.createContext("/api/expense/pending-finance", new ExpenseFinancePendingHandler());
        server.createContext("/api/expense/process-finance", new ExpenseFinanceProcessHandler());
        server.createContext("/api/expense/all", new AllExpenseHandler());

        // Purchase Requests Endpoints
        server.createContext("/api/purchase/apply", new ApplyPurchaseHandler());
        server.createContext("/api/purchase/employee", new EmployeePurchaseHandler());
        server.createContext("/api/purchase/pending-manager", new PurchaseManagerPendingHandler());
        server.createContext("/api/purchase/process-manager", new PurchaseManagerProcessHandler());
        server.createContext("/api/purchase/pending-finance", new PurchaseFinancePendingHandler());
        server.createContext("/api/purchase/process-finance", new PurchaseFinanceProcessHandler());
        server.createContext("/api/purchase/all", new AllPurchaseHandler());

        // Static Web Dashboard Files Handler
        server.createContext("/", new StaticFileHandler());

        server.setExecutor(null);
        System.out.println("==================================================");
        System.out.println("🚀 NexusFlow Universal Web Server running on port " + PORT);
        System.out.println("🌐 Open http://localhost:" + PORT + " in your browser!");
        System.out.println("==================================================");
        server.start();
    }

    private static void sendJsonResponse(HttpExchange exchange, int statusCode, String jsonResponse) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        byte[] bytes = jsonResponse.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static String readRequestBody(HttpExchange exchange) throws IOException {
        try (InputStream is = exchange.getRequestBody();
             InputStreamReader isr = new InputStreamReader(is, StandardCharsets.UTF_8);
             BufferedReader br = new BufferedReader(isr)) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    private static String extractJsonField(String json, String field) {
        if (json == null || field == null) return "";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("[\"\\\\]*" + field + "[\"\\\\]*\\s*:\\s*(\"[^\"]*\"|[^,\\}\\s]+)");
        java.util.regex.Matcher m = p.matcher(json);
        if (m.find()) {
            String val = m.group(1).trim();
            val = val.replaceAll("^[\"\\\\]+|[\"\\\\]+$", "");
            return val;
        }
        return "";
    }

    // Login Handler
    static class LoginHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) { sendJsonResponse(exchange, 204, ""); return; }
            String body = readRequestBody(exchange);
            String username = extractJsonField(body, "username");
            String password = extractJsonField(body, "password");

            try {
                User user = authService.login(username, password);
                if (user != null) {
                    String json = String.format("{\"success\":true,\"user\":{\"id\":%d,\"username\":\"%s\",\"fullName\":\"%s\",\"email\":\"%s\",\"role\":\"%s\"}}",
                            user.getId(), user.getUsername(), user.getFullName(), user.getEmail(), user.getRole().name());
                    sendJsonResponse(exchange, 200, json);
                } else {
                    sendJsonResponse(exchange, 401, "{\"success\":false,\"message\":\"Invalid username or password\"}");
                }
            } catch (Exception e) {
                sendJsonResponse(exchange, 500, "{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
            }
        }
    }

    // Register Handler
    static class RegisterHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) { sendJsonResponse(exchange, 204, ""); return; }
            String body = readRequestBody(exchange);
            String username = extractJsonField(body, "username");
            String password = extractJsonField(body, "password");
            String fullName = extractJsonField(body, "fullName");
            String email = extractJsonField(body, "email");
            String role = extractJsonField(body, "role");

            try {
                boolean success = authService.register(username, password, fullName, email, role);
                if (success) {
                    sendJsonResponse(exchange, 200, "{\"success\":true,\"message\":\"Account registered successfully! Please log in.\"}");
                } else {
                    sendJsonResponse(exchange, 400, "{\"success\":false,\"message\":\"Registration failed.\"}");
                }
            } catch (Exception e) {
                sendJsonResponse(exchange, 400, "{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
            }
        }
    }

    // --- LEAVE HANDLERS ---
    static class ApplyLeaveHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) { sendJsonResponse(exchange, 204, ""); return; }
            try {
                String body = readRequestBody(exchange);
                int employeeId = Integer.parseInt(extractJsonField(body, "employeeId"));
                String leaveType = extractJsonField(body, "leaveType");
                Date startDate = Date.valueOf(extractJsonField(body, "startDate"));
                Date endDate = Date.valueOf(extractJsonField(body, "endDate"));
                String reason = extractJsonField(body, "reason");

                User emp = new User(); emp.setId(employeeId); emp.setRole(Role.EMPLOYEE);
                boolean success = leaveService.applyForLeave(emp, leaveType, startDate, endDate, reason);
                sendJsonResponse(exchange, 200, "{\"success\":" + success + "}");
            } catch (Exception e) {
                sendJsonResponse(exchange, 500, "{\"success\":false,\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}");
            }
        }
    }

    static class EmployeeLeaveHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                String query = exchange.getRequestURI().getQuery();
                int empId = 0;
                if (query != null && query.contains("id=")) {
                    empId = Integer.parseInt(query.split("id=")[1].split("&")[0]);
                }
                sendJsonResponse(exchange, 200, toJsonLeaveList(leaveService.getEmployeeLeaveRequests(empId)));
            } catch (Exception e) { sendJsonResponse(exchange, 200, "[]"); }
        }
    }

    static class ManagerPendingHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try { sendJsonResponse(exchange, 200, toJsonLeaveList(leaveService.getManagerPendingRequests())); }
            catch (Exception e) { sendJsonResponse(exchange, 500, "[]"); }
        }
    }

    static class ManagerProcessHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) { sendJsonResponse(exchange, 204, ""); return; }
            try {
                String body = readRequestBody(exchange);
                int managerId = Integer.parseInt(extractJsonField(body, "managerId"));
                int reqId = Integer.parseInt(extractJsonField(body, "requestId"));
                boolean approve = Boolean.parseBoolean(extractJsonField(body, "approve"));
                String comment = extractJsonField(body, "comment");

                User mgr = new User(); mgr.setId(managerId); mgr.setRole(Role.MANAGER);
                boolean success = leaveService.processManagerDecision(mgr, reqId, approve, comment);
                sendJsonResponse(exchange, 200, "{\"success\":" + success + "}");
            } catch (Exception e) {
                sendJsonResponse(exchange, 500, "{\"success\":false,\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}");
            }
        }
    }

    static class HrPendingHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try { sendJsonResponse(exchange, 200, toJsonLeaveList(leaveService.getHrPendingRequests())); }
            catch (Exception e) { sendJsonResponse(exchange, 500, "[]"); }
        }
    }

    static class HrProcessHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) { sendJsonResponse(exchange, 204, ""); return; }
            try {
                String body = readRequestBody(exchange);
                int hrId = Integer.parseInt(extractJsonField(body, "hrId"));
                int reqId = Integer.parseInt(extractJsonField(body, "requestId"));
                boolean approve = Boolean.parseBoolean(extractJsonField(body, "approve"));
                String comment = extractJsonField(body, "comment");

                User hr = new User(); hr.setId(hrId); hr.setRole(Role.HR);
                boolean success = leaveService.processHrDecision(hr, reqId, approve, comment);
                sendJsonResponse(exchange, 200, "{\"success\":" + success + "}");
            } catch (Exception e) {
                sendJsonResponse(exchange, 500, "{\"success\":false,\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}");
            }
        }
    }

    static class AllLeaveHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try { sendJsonResponse(exchange, 200, toJsonLeaveList(leaveService.getAllLeaveRequests())); }
            catch (Exception e) { sendJsonResponse(exchange, 500, "[]"); }
        }
    }

    // --- EXPENSE HANDLERS ---
    static class ApplyExpenseHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) { sendJsonResponse(exchange, 204, ""); return; }
            try {
                String body = readRequestBody(exchange);
                int empId = Integer.parseInt(extractJsonField(body, "employeeId"));
                String category = extractJsonField(body, "category");
                double amount = Double.parseDouble(extractJsonField(body, "amount"));
                String description = extractJsonField(body, "description");

                User emp = new User(); emp.setId(empId); emp.setRole(Role.EMPLOYEE);
                boolean success = expenseService.applyExpenseClaim(emp, category, amount, description);
                sendJsonResponse(exchange, 200, "{\"success\":" + success + "}");
            } catch (Exception e) {
                sendJsonResponse(exchange, 500, "{\"success\":false,\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}");
            }
        }
    }

    static class EmployeeExpenseHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                int empId = Integer.parseInt(exchange.getRequestURI().getQuery().split("=")[1]);
                sendJsonResponse(exchange, 200, toJsonExpenseList(expenseService.getEmployeeClaims(empId)));
            } catch (Exception e) { sendJsonResponse(exchange, 500, "[]"); }
        }
    }

    static class ExpenseManagerPendingHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try { sendJsonResponse(exchange, 200, toJsonExpenseList(expenseService.getManagerPendingClaims())); }
            catch (Exception e) { sendJsonResponse(exchange, 500, "[]"); }
        }
    }

    static class ExpenseManagerProcessHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) { sendJsonResponse(exchange, 204, ""); return; }
            try {
                String body = readRequestBody(exchange);
                int mgrId = Integer.parseInt(extractJsonField(body, "managerId"));
                int claimId = Integer.parseInt(extractJsonField(body, "claimId"));
                boolean approve = Boolean.parseBoolean(extractJsonField(body, "approve"));
                String comment = extractJsonField(body, "comment");

                User mgr = new User(); mgr.setId(mgrId); mgr.setRole(Role.MANAGER);
                boolean success = expenseService.processManagerDecision(mgr, claimId, approve, comment);
                sendJsonResponse(exchange, 200, "{\"success\":" + success + "}");
            } catch (Exception e) {
                sendJsonResponse(exchange, 500, "{\"success\":false,\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}");
            }
        }
    }

    static class ExpenseFinancePendingHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try { sendJsonResponse(exchange, 200, toJsonExpenseList(expenseService.getFinancePendingClaims())); }
            catch (Exception e) { sendJsonResponse(exchange, 500, "[]"); }
        }
    }

    static class ExpenseFinanceProcessHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) { sendJsonResponse(exchange, 204, ""); return; }
            try {
                String body = readRequestBody(exchange);
                int finId = Integer.parseInt(extractJsonField(body, "financeId"));
                int claimId = Integer.parseInt(extractJsonField(body, "claimId"));
                boolean approve = Boolean.parseBoolean(extractJsonField(body, "approve"));
                String comment = extractJsonField(body, "comment");

                User fin = new User(); fin.setId(finId); fin.setRole(Role.HR);
                boolean success = expenseService.processFinanceDecision(fin, claimId, approve, comment);
                sendJsonResponse(exchange, 200, "{\"success\":" + success + "}");
            } catch (Exception e) {
                sendJsonResponse(exchange, 500, "{\"success\":false,\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}");
            }
        }
    }

    static class AllExpenseHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try { sendJsonResponse(exchange, 200, toJsonExpenseList(expenseService.getAllClaims())); }
            catch (Exception e) { sendJsonResponse(exchange, 500, "[]"); }
        }
    }

    // --- PURCHASE HANDLERS ---
    static class ApplyPurchaseHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) { sendJsonResponse(exchange, 204, ""); return; }
            try {
                String body = readRequestBody(exchange);
                int empId = Integer.parseInt(extractJsonField(body, "employeeId"));
                String itemName = extractJsonField(body, "itemName");
                int quantity = Integer.parseInt(extractJsonField(body, "quantity"));
                double cost = Double.parseDouble(extractJsonField(body, "estimatedCost"));
                String reason = extractJsonField(body, "reason");

                User emp = new User(); emp.setId(empId); emp.setRole(Role.EMPLOYEE);
                boolean success = purchaseService.applyPurchaseRequest(emp, itemName, quantity, cost, reason);
                sendJsonResponse(exchange, 200, "{\"success\":" + success + "}");
            } catch (Exception e) {
                sendJsonResponse(exchange, 500, "{\"success\":false,\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}");
            }
        }
    }

    static class EmployeePurchaseHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                int empId = Integer.parseInt(exchange.getRequestURI().getQuery().split("=")[1]);
                sendJsonResponse(exchange, 200, toJsonPurchaseList(purchaseService.getEmployeeRequests(empId)));
            } catch (Exception e) { sendJsonResponse(exchange, 500, "[]"); }
        }
    }

    static class PurchaseManagerPendingHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try { sendJsonResponse(exchange, 200, toJsonPurchaseList(purchaseService.getManagerPendingRequests())); }
            catch (Exception e) { sendJsonResponse(exchange, 500, "[]"); }
        }
    }

    static class PurchaseManagerProcessHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) { sendJsonResponse(exchange, 204, ""); return; }
            try {
                String body = readRequestBody(exchange);
                int mgrId = Integer.parseInt(extractJsonField(body, "managerId"));
                int reqId = Integer.parseInt(extractJsonField(body, "requestId"));
                boolean approve = Boolean.parseBoolean(extractJsonField(body, "approve"));
                String comment = extractJsonField(body, "comment");

                User mgr = new User(); mgr.setId(mgrId); mgr.setRole(Role.MANAGER);
                boolean success = purchaseService.processManagerDecision(mgr, reqId, approve, comment);
                sendJsonResponse(exchange, 200, "{\"success\":" + success + "}");
            } catch (Exception e) {
                sendJsonResponse(exchange, 500, "{\"success\":false,\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}");
            }
        }
    }

    static class PurchaseFinancePendingHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try { sendJsonResponse(exchange, 200, toJsonPurchaseList(purchaseService.getFinancePendingRequests())); }
            catch (Exception e) { sendJsonResponse(exchange, 500, "[]"); }
        }
    }

    static class PurchaseFinanceProcessHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) { sendJsonResponse(exchange, 204, ""); return; }
            try {
                String body = readRequestBody(exchange);
                int finId = Integer.parseInt(extractJsonField(body, "financeId"));
                int reqId = Integer.parseInt(extractJsonField(body, "requestId"));
                boolean approve = Boolean.parseBoolean(extractJsonField(body, "approve"));
                String comment = extractJsonField(body, "comment");

                User fin = new User(); fin.setId(finId); fin.setRole(Role.HR);
                boolean success = purchaseService.processFinanceDecision(fin, reqId, approve, comment);
                sendJsonResponse(exchange, 200, "{\"success\":" + success + "}");
            } catch (Exception e) {
                sendJsonResponse(exchange, 500, "{\"success\":false,\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}");
            }
        }
    }

    static class AllPurchaseHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try { sendJsonResponse(exchange, 200, toJsonPurchaseList(purchaseService.getAllRequests())); }
            catch (Exception e) { sendJsonResponse(exchange, 500, "[]"); }
        }
    }

    // Audit Logs Handler
    static class AuditLogsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                List<AuditLog> logs = auditLogDAO.findAll();
                StringBuilder sb = new StringBuilder("[");
                for (int i = 0; i < logs.size(); i++) {
                    AuditLog l = logs.get(i);
                    sb.append(String.format("{\"id\":%d,\"userId\":%d,\"userRole\":\"%s\",\"action\":\"%s\",\"details\":\"%s\",\"timestamp\":\"%s\"}",
                            l.getId(), l.getUserId(), l.getUserRole(), l.getAction(),
                            l.getDetails().replace("\"", "\\\""), l.getTimestamp()));
                    if (i < logs.size() - 1) sb.append(",");
                }
                sb.append("]");
                sendJsonResponse(exchange, 200, sb.toString());
            } catch (Exception e) {
                sendJsonResponse(exchange, 500, "[]");
            }
        }
    }

    // Static Web File Handler
    static class StaticFileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            if (path.equals("/")) path = "/index.html";

            File file = new File("web" + path);
            if (!file.exists() || file.isDirectory()) file = new File("web/index.html");

            if (file.exists()) {
                String contentType = "text/html";
                if (path.endsWith(".css")) contentType = "text/css";
                else if (path.endsWith(".js")) contentType = "application/javascript";
                else if (path.endsWith(".json")) contentType = "application/json";

                exchange.getResponseHeaders().set("Content-Type", contentType);
                exchange.sendResponseHeaders(200, file.length());
                try (InputStream is = new FileInputStream(file); OutputStream os = exchange.getResponseBody()) {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = is.read(buffer)) != -1) os.write(buffer, 0, bytesRead);
                }
            } else {
                String notFound = "<h1>404 Not Found</h1>";
                exchange.sendResponseHeaders(404, notFound.length());
                try (OutputStream os = exchange.getResponseBody()) { os.write(notFound.getBytes()); }
            }
        }
    }

    private static String escapeJson(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }

    private static String toJsonLeaveList(List<LeaveRequest> list) {
        if (list == null) return "[]";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            LeaveRequest r = list.get(i);
            sb.append(String.format("{\"id\":%d,\"employeeId\":%d,\"employeeName\":\"%s\",\"leaveType\":\"%s\",\"startDate\":\"%s\",\"endDate\":\"%s\",\"reason\":\"%s\",\"status\":\"%s\",\"managerComment\":\"%s\",\"hrComment\":\"%s\"}",
                    r.getId(), r.getEmployeeId(), escapeJson(r.getEmployeeName()),
                    escapeJson(r.getLeaveType()), escapeJson(String.valueOf(r.getStartDate())), escapeJson(String.valueOf(r.getEndDate())), escapeJson(r.getReason()),
                    r.getStatus() != null ? r.getStatus().name() : "PENDING_MANAGER",
                    escapeJson(r.getManagerComment()), escapeJson(r.getHrComment())));
            if (i < list.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    private static String toJsonExpenseList(List<ExpenseClaim> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            ExpenseClaim c = list.get(i);
            sb.append(String.format("{\"id\":%d,\"employeeId\":%d,\"employeeName\":\"%s\",\"category\":\"%s\",\"amount\":%.2f,\"description\":\"%s\",\"status\":\"%s\",\"managerComment\":\"%s\",\"financeComment\":\"%s\"}",
                    c.getId(), c.getEmployeeId(), c.getEmployeeName() != null ? c.getEmployeeName() : "",
                    c.getCategory(), c.getAmount(), c.getDescription().replace("\"", "\\\""),
                    c.getStatus(), c.getManagerComment() != null ? c.getManagerComment().replace("\"", "\\\"") : "",
                    c.getFinanceComment() != null ? c.getFinanceComment().replace("\"", "\\\"") : ""));
            if (i < list.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    private static String toJsonPurchaseList(List<PurchaseRequest> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            PurchaseRequest p = list.get(i);
            sb.append(String.format("{\"id\":%d,\"employeeId\":%d,\"employeeName\":\"%s\",\"itemName\":\"%s\",\"quantity\":%d,\"estimatedCost\":%.2f,\"reason\":\"%s\",\"status\":\"%s\",\"managerComment\":\"%s\",\"financeComment\":\"%s\"}",
                    p.getId(), p.getEmployeeId(), p.getEmployeeName() != null ? p.getEmployeeName() : "",
                    p.getItemName().replace("\"", "\\\""), p.getQuantity(), p.getEstimatedCost(),
                    p.getReason().replace("\"", "\\\""), p.getStatus(),
                    p.getManagerComment() != null ? p.getManagerComment().replace("\"", "\\\"") : "",
                    p.getFinanceComment() != null ? p.getFinanceComment().replace("\"", "\\\"") : ""));
            if (i < list.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }
}
