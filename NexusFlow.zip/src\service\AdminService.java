package service;

import dao.AuditLogDAO;
import model.AuditLog;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

public class AdminService {

    private final AuditLogDAO auditLogDAO = new AuditLogDAO();

    public boolean exportAuditLogsToCSV(String filename) throws SQLException {
        List<AuditLog> logs = auditLogDAO.findAll();
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            writer.println("ID,Timestamp,UserID,UserRole,Action,Details");
            for (AuditLog log : logs) {
                writer.printf("%d,\"%s\",%d,\"%s\",\"%s\",\"%s\"\n",
                        log.getId(), 
                        log.getTimestamp(), 
                        log.getUserId(),
                        log.getUserRole(), 
                        log.getAction(),
                        log.getDetails().replace("\"", "\"\""));
            }
            return true;
        } catch (Exception e) {
            System.err.println("❌ CSV Export failed: " + e.getMessage());
            return false;
        }
    }
}