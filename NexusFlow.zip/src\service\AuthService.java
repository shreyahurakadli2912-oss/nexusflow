package service;

import dao.UserDAO;
import model.Role;
import model.User;

import java.sql.SQLException;

public class AuthService {

    private final UserDAO userDAO = new UserDAO();

    public User login(String username, String password) throws SQLException {
        User user = userDAO.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }

    public boolean register(String username, String password, String fullName, String email, String roleStr) throws SQLException {
        if (userDAO.findByUsername(username) != null) {
            throw new IllegalArgumentException("Username already exists!");
        }
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setFullName(fullName);
        user.setEmail(email);
        user.setRole(Role.fromString(roleStr));
        return userDAO.registerUser(user);
    }
}