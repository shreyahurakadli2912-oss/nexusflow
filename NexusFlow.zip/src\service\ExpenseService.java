package service;

import dao.AuditLogDAO;
import dao.ExpenseDAO;
import model.AuditLog;
import model.ExpenseClaim;
import model.User;

import java.sql.SQLException;
import java.util.List;

public class ExpenseService {

    private final ExpenseDAO expenseDAO = new ExpenseDAO();
    private final AuditLogDAO auditLogDAO = new AuditLogDAO();

    public boolean applyExpenseClaim(User employee, String category, double amount, String description) throws SQLException {
        ExpenseClaim claim = new ExpenseClaim();
        claim.setEmployeeId(employee.getId());
        claim.setCategory(category);
        claim.setAmount(amount);
        claim.setDescription(description);

        boolean success = expenseDAO.createClaim(claim);
        if (success) {
            auditLogDAO.logAction(new AuditLog(
                    employee.getId(), employee.getRole().name(),
                    "APPLY_EXPENSE", "Employee submitted expense claim $" + amount + " for " + category
            ));
        }
        return success;
    }

    public List<ExpenseClaim> getEmployeeClaims(int empId) throws SQLException {
        return expenseDAO.findByEmployeeId(empId);
    }

    public List<ExpenseClaim> getManagerPendingClaims() throws SQLException {
        return expenseDAO.findByStatus("PENDING_MANAGER");
    }

    public boolean processManagerDecision(User manager, int claimId, boolean approve, String comment) throws SQLException {
        String newStatus = approve ? "PENDING_FINANCE" : "REJECTED_BY_MANAGER";
        boolean success = expenseDAO.updateStatusAndManagerComment(claimId, newStatus, comment);
        if (success) {
            auditLogDAO.logAction(new AuditLog(
                    manager.getId(), manager.getRole().name(),
                    approve ? "EXPENSE_MANAGER_APPROVE" : "EXPENSE_MANAGER_REJECT",
                    "Manager " + (approve ? "approved" : "rejected") + " Expense Claim #" + claimId
            ));
        }
        return success;
    }

    public List<ExpenseClaim> getFinancePendingClaims() throws SQLException {
        return expenseDAO.findByStatus("PENDING_FINANCE");
    }

    public boolean processFinanceDecision(User finance, int claimId, boolean approve, String comment) throws SQLException {
        String newStatus = approve ? "REIMBURSED" : "REJECTED_BY_FINANCE";
        boolean success = expenseDAO.updateStatusAndFinanceComment(claimId, newStatus, comment);
        if (success) {
            auditLogDAO.logAction(new AuditLog(
                    finance.getId(), finance.getRole().name(),
                    approve ? "EXPENSE_REIMBURSED" : "EXPENSE_FINANCE_REJECT",
                    "Finance " + (approve ? "REIMBURSED (Money Transferred)" : "rejected") + " Expense Claim #" + claimId
            ));
        }
        return success;
    }

    public List<ExpenseClaim> getAllClaims() throws SQLException {
        return expenseDAO.findAll();
    }
}
