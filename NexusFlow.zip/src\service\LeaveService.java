package service;

import dao.AuditLogDAO;
import dao.LeaveRequestDAO;
import model.AuditLog;
import model.LeaveRequest;
import model.LeaveStatus;
import model.User;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class LeaveService {

    private final LeaveRequestDAO leaveRequestDAO = new LeaveRequestDAO();
    private final AuditLogDAO auditLogDAO = new AuditLogDAO();

    public boolean applyForLeave(User employee, String leaveType, Date startDate, Date endDate, String reason) throws SQLException {
        LeaveRequest req = new LeaveRequest();
        req.setEmployeeId(employee.getId());
        req.setLeaveType(leaveType);
        req.setStartDate(startDate);
        req.setEndDate(endDate);
        req.setReason(reason);
        req.setStatus(LeaveStatus.PENDING_MANAGER);

        boolean success = leaveRequestDAO.createLeaveRequest(req);
        if (success) {
            auditLogDAO.logAction(new AuditLog(
                    employee.getId(), employee.getRole().name(),
                    "APPLY_LEAVE", "Employee applied for " + leaveType + " leave from " + startDate + " to " + endDate
            ));
        }
        return success;
    }

    public List<LeaveRequest> getEmployeeLeaveRequests(int employeeId) throws SQLException {
        return leaveRequestDAO.findByEmployeeId(employeeId);
    }

    public List<LeaveRequest> getManagerPendingRequests() throws SQLException {
        return leaveRequestDAO.findByStatus(LeaveStatus.PENDING_MANAGER);
    }

    public boolean processManagerDecision(User manager, int requestId, boolean approve, String comment) throws SQLException {
        LeaveRequest req = leaveRequestDAO.findById(requestId);
        if (req == null) throw new IllegalArgumentException("Leave Request ID #" + requestId + " does not exist.");

        LeaveStatus newStatus = approve ? LeaveStatus.PENDING_HR : LeaveStatus.REJECTED_BY_MANAGER;
        boolean success = leaveRequestDAO.updateStatusAndManagerComment(requestId, newStatus, comment);

        if (success) {
            auditLogDAO.logAction(new AuditLog(
                    manager.getId(), manager.getRole().name(),
                    approve ? "MANAGER_APPROVE" : "MANAGER_REJECT",
                    "Manager " + (approve ? "approved" : "rejected") + " Request #" + requestId + ". Comment: " + comment
            ));
        }
        return success;
    }

    public List<LeaveRequest> getHrPendingRequests() throws SQLException {
        return leaveRequestDAO.findByStatus(LeaveStatus.PENDING_HR);
    }

    public boolean processHrDecision(User hr, int requestId, boolean approve, String comment) throws SQLException {
        LeaveRequest req = leaveRequestDAO.findById(requestId);
        if (req == null) throw new IllegalArgumentException("Leave Request ID #" + requestId + " does not exist.");

        LeaveStatus newStatus = approve ? LeaveStatus.APPROVED : LeaveStatus.REJECTED_BY_HR;
        boolean success = leaveRequestDAO.updateStatusAndHrComment(requestId, newStatus, comment);

        if (success) {
            auditLogDAO.logAction(new AuditLog(
                    hr.getId(), hr.getRole().name(),
                    approve ? "HR_FINAL_APPROVE" : "HR_FINAL_REJECT",
                    "HR " + (approve ? "granted FINAL APPROVAL for" : "REJECTED") + " Request #" + requestId + ". Comment: " + comment
            ));
        }
        return success;
    }

    public List<LeaveRequest> getAllLeaveRequests() throws SQLException {
        return leaveRequestDAO.findAll();
    }
}