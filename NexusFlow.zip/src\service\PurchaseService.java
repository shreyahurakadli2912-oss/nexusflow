package service;

import dao.AuditLogDAO;
import dao.PurchaseDAO;
import model.AuditLog;
import model.PurchaseRequest;
import model.User;

import java.sql.SQLException;
import java.util.List;

public class PurchaseService {

    private final PurchaseDAO purchaseDAO = new PurchaseDAO();
    private final AuditLogDAO auditLogDAO = new AuditLogDAO();

    public boolean applyPurchaseRequest(User employee, String itemName, int quantity, double estimatedCost, String reason) throws SQLException {
        PurchaseRequest req = new PurchaseRequest();
        req.setEmployeeId(employee.getId());
        req.setItemName(itemName);
        req.setQuantity(quantity);
        req.setEstimatedCost(estimatedCost);
        req.setReason(reason);

        boolean success = purchaseDAO.createRequest(req);
        if (success) {
            auditLogDAO.logAction(new AuditLog(
                    employee.getId(), employee.getRole().name(),
                    "RAISE_PURCHASE_REQ", "Employee raised purchase request for " + quantity + "x " + itemName + " ($" + estimatedCost + ")"
            ));
        }
        return success;
    }

    public List<PurchaseRequest> getEmployeeRequests(int empId) throws SQLException {
        return purchaseDAO.findByEmployeeId(empId);
    }

    public List<PurchaseRequest> getManagerPendingRequests() throws SQLException {
        return purchaseDAO.findByStatus("PENDING_MANAGER");
    }

    public boolean processManagerDecision(User manager, int reqId, boolean approve, String comment) throws SQLException {
        String newStatus = approve ? "PENDING_FINANCE" : "REJECTED_BY_MANAGER";
        boolean success = purchaseDAO.updateStatusAndManagerComment(reqId, newStatus, comment);
        if (success) {
            auditLogDAO.logAction(new AuditLog(
                    manager.getId(), manager.getRole().name(),
                    approve ? "PURCHASE_MANAGER_APPROVE" : "PURCHASE_MANAGER_REJECT",
                    "Manager " + (approve ? "approved" : "rejected") + " Purchase Request #" + reqId
            ));
        }
        return success;
    }

    public List<PurchaseRequest> getFinancePendingRequests() throws SQLException {
        return purchaseDAO.findByStatus("PENDING_FINANCE");
    }

    public boolean processFinanceDecision(User finance, int reqId, boolean approve, String comment) throws SQLException {
        String newStatus = approve ? "PURCHASED_&_DELIVERED" : "REJECTED_BY_FINANCE";
        boolean success = purchaseDAO.updateStatusAndFinanceComment(reqId, newStatus, comment);
        if (success) {
            auditLogDAO.logAction(new AuditLog(
                    finance.getId(), finance.getRole().name(),
                    approve ? "PURCHASE_COMPLETED" : "PURCHASE_FINANCE_REJECT",
                    "Finance " + (approve ? "APPROVED & PURCHASED" : "rejected") + " Purchase Request #" + reqId
            ));
        }
        return success;
    }

    public List<PurchaseRequest> getAllRequests() throws SQLException {
        return purchaseDAO.findAll();
    }
}
