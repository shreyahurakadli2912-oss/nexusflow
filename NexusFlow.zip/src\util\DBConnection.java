package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {

    private static final String MYSQL_HOST = "jdbc:mysql://localhost:3306/?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String MYSQL_DB = "jdbc:mysql://localhost:3306/nexusflow_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String H2_URL = "jdbc:h2:./db/nexusflow_db;MODE=MySQL;AUTO_SERVER=TRUE";

    private static String activeUrl = H2_URL;
    private static String activeUser = "sa";
    private static String activePassword = "";

    static {
        initializeEngine();
    }

    private static void initializeEngine() {
        String[] possibleMysqlPasswords = {"Nexus@29", "root", "", "1234", "password", "admin", "123456", "mysql"};
        boolean mysqlConnected = false;

        // Try MySQL Driver first
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            for (String pwd : possibleMysqlPasswords) {
                try (Connection conn = DriverManager.getConnection(MYSQL_HOST, "root", pwd)) {
                    activeUrl = MYSQL_DB;
                    activeUser = "root";
                    activePassword = pwd;
                    mysqlConnected = true;
                    initMysqlDb(conn);
                    System.out.println("✅ Connected to MySQL Server successfully!");
                    break;
                } catch (SQLException ignored) {}
            }
        } catch (ClassNotFoundException ignored) {}

        // Fallback to Embedded DB if MySQL credentials failed
        if (!mysqlConnected) {
            try {
                Class.forName("org.h2.Driver");
                activeUrl = H2_URL;
                activeUser = "sa";
                activePassword = "";
                try (Connection conn = DriverManager.getConnection(H2_URL, "sa", "")) {
                    initH2Db(conn);
                    System.out.println("✅ Database Engine Ready!");
                }
            } catch (Exception e) {
                System.err.println("❌ Database Initialization Error: " + e.getMessage());
            }
        }
    }

    private static void initMysqlDb(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS nexusflow_db");
            stmt.executeUpdate("USE nexusflow_db");
            createTablesAndSeed(stmt);
        }
    }

    private static void initH2Db(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            createTablesAndSeed(stmt);
        }
    }

    private static void createTablesAndSeed(Statement stmt) throws SQLException {
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS users (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "company_id VARCHAR(50) NOT NULL DEFAULT 'NEXUSFLOW_CORP', " +
                "username VARCHAR(50) NOT NULL UNIQUE, " +
                "password VARCHAR(255) NOT NULL, " +
                "full_name VARCHAR(100) NOT NULL, " +
                "email VARCHAR(100) NOT NULL, " +
                "role VARCHAR(20) NOT NULL)");

        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS leave_requests (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "company_id VARCHAR(50) NOT NULL DEFAULT 'NEXUSFLOW_CORP', " +
                "employee_id INT NOT NULL, " +
                "leave_type VARCHAR(20) NOT NULL, " +
                "start_date DATE NOT NULL, " +
                "end_date DATE NOT NULL, " +
                "reason VARCHAR(255) NOT NULL, " +
                "status VARCHAR(30) NOT NULL DEFAULT 'PENDING_MANAGER', " +
                "manager_comment VARCHAR(255), " +
                "hr_comment VARCHAR(255), " +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS audit_logs (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "company_id VARCHAR(50) NOT NULL DEFAULT 'NEXUSFLOW_CORP', " +
                "user_id INT NOT NULL, " +
                "user_role VARCHAR(20) NOT NULL, " +
                "action VARCHAR(100) NOT NULL, " +
                "details VARCHAR(255), " +
                "timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS expense_claims (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "company_id VARCHAR(50) NOT NULL DEFAULT 'NEXUSFLOW_CORP', " +
                "employee_id INT NOT NULL, " +
                "category VARCHAR(50) NOT NULL, " +
                "amount DOUBLE NOT NULL, " +
                "description VARCHAR(255) NOT NULL, " +
                "status VARCHAR(30) NOT NULL DEFAULT 'PENDING_MANAGER', " +
                "manager_comment VARCHAR(255), " +
                "finance_comment VARCHAR(255), " +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS purchase_requests (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "company_id VARCHAR(50) NOT NULL DEFAULT 'NEXUSFLOW_CORP', " +
                "employee_id INT NOT NULL, " +
                "item_name VARCHAR(100) NOT NULL, " +
                "quantity INT NOT NULL, " +
                "estimated_cost DOUBLE NOT NULL, " +
                "reason VARCHAR(255) NOT NULL, " +
                "status VARCHAR(30) NOT NULL DEFAULT 'PENDING_MANAGER', " +
                "manager_comment VARCHAR(255), " +
                "finance_comment VARCHAR(255), " +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        try { stmt.executeUpdate("ALTER TABLE users ADD COLUMN IF NOT EXISTS company_id VARCHAR(50) DEFAULT 'nexusflow.com'"); } catch (Exception ignored) {}
        try { stmt.executeUpdate("ALTER TABLE leave_requests ADD COLUMN IF NOT EXISTS company_id VARCHAR(50) DEFAULT 'nexusflow.com'"); } catch (Exception ignored) {}
        try { stmt.executeUpdate("ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS company_id VARCHAR(50) DEFAULT 'nexusflow.com'"); } catch (Exception ignored) {}
        try { stmt.executeUpdate("ALTER TABLE expense_claims ADD COLUMN IF NOT EXISTS company_id VARCHAR(50) DEFAULT 'nexusflow.com'"); } catch (Exception ignored) {}
        try { stmt.executeUpdate("ALTER TABLE purchase_requests ADD COLUMN IF NOT EXISTS company_id VARCHAR(50) DEFAULT 'nexusflow.com'"); } catch (Exception ignored) {}

        stmt.executeUpdate("MERGE INTO users (id, company_id, username, password, full_name, email, role) KEY(username) VALUES " +
                "(1, 'nexusflow.com', 'admin', 'Admin@Nexus2026', 'System Administrator', 'admin@nexusflow.com', 'ADMIN'), " +
                "(2, 'nexusflow.com', 'hr_sarah', 'Hr@Sarah2026', 'Sarah Jenkins (HR Head)', 'sarah@nexusflow.com', 'HR'), " +
                "(3, 'nexusflow.com', 'mgr_bob', 'Mgr@Bob2026', 'Bob Smith (Engineering Lead)', 'bob@nexusflow.com', 'MANAGER'), " +
                "(4, 'nexusflow.com', 'emp_john', 'Emp@John2026', 'John Doe (Software Engineer)', 'john@nexusflow.com', 'EMPLOYEE')");
    }

    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(activeUrl, activeUser, activePassword);
        } catch (SQLException e) {
            System.err.println("❌ Connection Failed: " + e.getMessage());
            return null;
        }
    }
}